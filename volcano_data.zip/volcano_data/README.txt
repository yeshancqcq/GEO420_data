
Volcanic Input files

andes_30ka: dates of volcanic events in andean arc <= 30 ka
VOGRIPAV2_global: dates of global explosive volcanic events <= 30 ka (sourced from VOGRIPA/LaMEVE database out of Bristol) 
VOGRIPAV2_g: dates of explosive volcanic events in glaciated regions (for global) <= 30 ka (sourced from VOGRIPA/LaMEVE database out of Bristol--regions listed in Brown et al 2014 supplement) 
VOGRIPAV2_nong: dates of explosive volcanic events in NON-glaciated regions (for global) <= 30 ka (sourced from VOGRIPA/LaMEVE database out of Bristol--regions listed in Brown et al 2014 supplement) 
AK: Alaska region from VOGRIPA (<= 30 ka) 
KA: Kamchatka region from VOGRIPA (<=30 ka) 
NZ: New Zealand region from VOGRIPA (<=30 ka) 
CWUS: Canada (1 record) + Cascades from VOGRIPA (<=30 ka) 
SA: S. Andes from VOGRIPA (<=30 ka) 


